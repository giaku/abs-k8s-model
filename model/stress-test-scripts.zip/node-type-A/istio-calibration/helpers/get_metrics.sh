python3.8 /root/new-calibration-old-paper/helpers/polling_script.py $1 $2 $3 $4 $5 > $6
